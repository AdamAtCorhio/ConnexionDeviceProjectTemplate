# CORHIO's Visual Studio Templates for Connexion Devices

## Intallation

User Visual Studio Templates are installed here:

    C:\Users\[YOUR_USERNAME_HERE]\Documents\Visual Studio 2019\Templates\ProjectTemplates\Visual C#\

Just extract/place the **CORHIO Connexion Device Library** folder in this location

## How to use

When creating a new project in Visual Studio, just search for **Connexion** or **CORHIO**

